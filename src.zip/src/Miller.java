import java.util.Scanner;

/**
 * Created by deepak on 5/4/16.
 */
public class Miller {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

    }
}
